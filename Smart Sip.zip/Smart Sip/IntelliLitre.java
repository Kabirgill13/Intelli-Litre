// UI system for the product

import java.util.Scanner;

public class IntelliLitre {

    public static void main(String[] args) {
        
        Product bottle = new Product("Kabir", 1000);

        Scanner scanner = new Scanner(System.in);
        System.out.print(">");

        while (scanner.hasNextLine()) {
            
            String action = scanner.nextLine();

            if (action.equalsIgnoreCase("ADDHYDR"))  {

                double amount = 0;
  
                System.out.print("Water Consumption: ");
                if (scanner.hasNextDouble()) {
                    amount = scanner.nextDouble();
                    scanner.nextLine();
                } 

                //Adds hydration
                bottle.addToHydrationlevel(amount);
 
            } else if (action.equalsIgnoreCase("GETHYDR"))  {
                System.out.println("You have consumed " + bottle.getHydrationlevel() + " mL of water today");

            } else if (action.equalsIgnoreCase("SETGOAL"))  {

                double goal = 0;
  
                System.out.print("Water Goal for Toady: ");
                if (scanner.hasNextDouble()) {
                    goal = scanner.nextDouble();
                    scanner.nextLine();
                } 

                bottle.setGoal(goal);

            } else if (action.equalsIgnoreCase("GETGOAL"))  {
                System.out.println(bottle.getGoal());

            } else if (action.equalsIgnoreCase("INFO"))  {
                System.out.println(bottle.printInfo());

            } else if (action.equalsIgnoreCase("PROCEED"))  {
                bottle.proceed();

            }

            System.out.print("\n>");
            
        }

    }
}
