//Class for bottle

import java.text.DecimalFormat;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Product {
    
    private String name; //Name of owner
    private double maxCapacity; //Max amount put in
    private double currentCapacity; //Current Capacity
    private double hydrationLevel; //Amount of hydration
    private double goal; //Hydration goal for the day
    private int count;
    
    public Product(String name, double maxCapacity) {
        this.name = name;
        this.maxCapacity = maxCapacity;
        currentCapacity = 0;
        hydrationLevel = 0;
        goal = 1900; //default goal
        count = 0;
    }

    //Updates Current Capacity
    public void updateCapacity(double capacity) {
        currentCapacity = capacity;
        setHydrationLevel();
    }

    //Adds to Hydration
    public void addToHydrationlevel(double hydration) {
        hydrationLevel += hydration;
    }

    //Sets the Hydration
    public void setHydrationLevel() {
        if (currentCapacity >= maxCapacity) {
            maxCapacity = currentCapacity;
        } else {
            hydrationLevel += (maxCapacity - currentCapacity);
            maxCapacity = currentCapacity;
        }
    }

    //Getter
    public double getHydrationlevel() {
        return hydrationLevel;
    }

    //Goal setter
    public void setGoal(double goal) {
        this.goal = goal;
    }

    //Goal getter
    public String getGoal() {
        DecimalFormat df = new DecimalFormat("#.##");
        String percent = df.format((hydrationLevel/goal) * 100);
        return ("You are " + percent + "% to your goal today!");
    }

    //Prints info
    public String printInfo() {
        return ("Intelli-Litre Bottle Owner: " + name + "\nCurrent Capacity: " + maxCapacity +
         " mL" + "\nTotal Comsumption: " + hydrationLevel + " mL" + "\n" + getGoal());
    }

    //Time skip to simulate time
    public void proceed() {
        
        count += 2;

        try {
            File inputFile = new File("bottleInfo.txt");
            Scanner in = new Scanner(inputFile);
            
            for (int i = 0; i < count; i++) {
                while (in.hasNextLine()) {
                    if (i + 1 == count || i + 2 == count) {
                        double capacity = in.nextDouble();
                        updateCapacity(capacity);
                    } in.nextLine();
                    break;
                }
            }
            System.out.println("Remember to Drink Water!");
        } catch (FileNotFoundException e) {
            System.out.println("File not Found");
        }
    }
}   
